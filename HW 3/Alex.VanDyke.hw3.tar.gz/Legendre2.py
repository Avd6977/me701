import numpy as np


def Legendre(x, l):
    c = (l-1)*[0]
    c.append(1)
    P = np.polynomial.legendre.legval(x, c)/(2.0/(2.0*l-1.0))
    return P