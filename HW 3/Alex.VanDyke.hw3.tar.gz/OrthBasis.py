'''
Created on Oct 13, 2014

@author: alex
'''

import numpy as np
from scipy.integrate import quad

class OrthBasis(object):
    '''
    classdocs
    '''
    def __init__(self, BasisType, Method):
        '''
        Constructor
        '''
        self.BasisType = BasisType
        self.Method = Method
        self.n = None
        
        
    def Transform(self, f, a, b):
        '''
        Transform the Function, f, with Orthogonal basis function, P
        '''
        self.a = a
        self.b = b
        func = self.n*[0]
        if self.BasisType == "Continuous":
            for l in range(self.n):
                self.g = lambda x: self.P[l](x,l)*f(x)
                func[l] = quad(self.g, self.a, self.b)[0]         
        elif self.BasisType == "Discrete":
            for l in range(self.n):
                x = np.linspace(self.a, self.b, 100)
                func[l] = np.dot(self.P[l](x),f(x))            
        else:
            print "INVALID BASIS TYPE: Please enter either Continuous or Discrete"
            raise NotImplementedError
        return func
    
    def InvTrans(self, func):
        '''
        Inverts the transform perfored on the fnction, finds approximate integral
        '''
        f_approx = 0
        if self.BasisType == "Continuous":
            for l in range(self.n):
                self.g = lambda x: func[l]*self.P[l](x,l)
                f_approx = quad(self.g, -1, 1)[0] + f_approx
        else:
            for l in range(self.n):
                f_approx += np.dot(func[l], self.P[l])
        return f_approx
    
               
            
    
    
    