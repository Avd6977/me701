'''
Created on Oct 13, 2014

@author: alex
'''
from OrthBasis import OrthBasis

class ContBasis(OrthBasis):
    '''
    classdocs
    '''


    def __init__(self, method):
        '''
        Constructor
        '''
        super(ContBasis, self).__init__("Continuous", method)
        
    
        