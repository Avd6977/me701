'''
Created on Oct 13, 2014

@author: alex
'''
from LegendrePolys import LegendrePolys
from FourierCont import FourierCont
from FourierDisc import FourierDisc
from scipy.integrate import quad
from scipy.special import jn as bessel

def f1(x):
    return x**2.0 + x + 1.0
def f2(x):
    return 1.0/(x**2.0 + 1.0)
def f3(x):
    return bessel(0, x)

LegPol = LegendrePolys(10)
FD = FourierDisc(10)

Tests = [f1, f2, f3]
print "Continuous Legendre Calculations"
for test in Tests:
    t = LegPol.Transform(test, 0.0, 10.0)
    t_inv = LegPol.InvTrans(t)
    t_quad = quad(test, 0.0, 10.0)
    t_error = abs(t_inv - t_quad[0])
    print (t_error, t_inv, t_quad[0])
     
# print '\n' 
#print "Coninuous Fourier Calculations"
# for test in Tests:
#     t = FourierCont.Transform(test, -1, 1)
#     t_inv = FourierCont.InvTrans(t)
#     t_quad = quad(test, -1, 1)
#     t_error = abs(t_inv - t_quad[0])
#     print (t_error, t_inv, t_quad[0])
#  
# print '\n'   
#print "Discrete Fourier Calculations"
#for test in Tests:
#    t = FD.Transform(test, -1, 1)
#    t_inv = FD.InvTrans(t)
#    t_quad = quad(test, -1, 1)
#    t_error = abs(t_inv - t_quad[0])
#    print (t_error, t_inv, t_quad[0])
