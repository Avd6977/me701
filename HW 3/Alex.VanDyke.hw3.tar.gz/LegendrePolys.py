'''
Created on Oct 13, 2014

@author: alex
'''
from ContBasis import ContBasis
from Legendre2 import Legendre

class LegendrePolys(ContBasis):
    '''
    classdocs
    '''


    def __init__(self, n):
        '''
        Constructor
        '''
        super(LegendrePolys, self).__init__("Continuous Legendre2 Transform")
        self.n = n
        self.P = self.Calc_P()     
                
    def Calc_P(self):
        n = self.n
        P = n*[0.0]
        for l in range(n):
            P[l] = Legendre
        return P
              
        